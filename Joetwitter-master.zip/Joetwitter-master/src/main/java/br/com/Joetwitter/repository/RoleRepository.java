package br.com.Joetwitter.repository;

import org.springframework.data.repository.CrudRepository;

import br.com.Joetwitter.model.Role;



public interface RoleRepository extends CrudRepository<Role, String>{

}
